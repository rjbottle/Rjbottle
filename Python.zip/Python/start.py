# Imports
import pygame

# Initilizing pygame
pygame.init()

#Creating The Screen
window = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Knightmare")
icon = pygame.image.load('icons/gameIcon.png')
pygame.display.set_icon(icon)
# Game Loop
running = True
while running:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False
	